/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;


public class PercolationTests {

    // Printing colored text in the Java console
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String TEST_PASSED = GREEN + " PASSED" + RESET;
    private static final String TEST_FAILED = RED + " FAILED" + RESET;

    public PercolationTests() {
    }

    private static void test1() {
        StdOut.println("TEST 1");
        In in = new In("input20.txt");      // input file
        int n = in.readInt();         // n-by-n percolation system
        Percolation p = new Percolation(n);
        while (!in.isEmpty()) {
            int i = in.readInt();
            int j = in.readInt();
            p.open(i, j);
            if (p.numberOfOpenSites() == 204) {
                if (p.percolates())
                    StdOut.println(TEST_PASSED);
                else
                    StdOut.println(TEST_FAILED);
            }
        }
    }

    private static void test2() {
        StdOut.println("TEST 2: percolation verticale haut vers bas");
        Percolation perc = new Percolation(4);
        int row, col;

        row = 1;
        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(1, 1) " + TEST_PASSED);
        else
            StdOut.println("open(1, 1) " + TEST_FAILED);

        row = 2;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        row = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);

        row = 4;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);
    }

    private static void test3() {
        StdOut.println("TEST 3: percolation verticale bas vers haut");
        Percolation perc = new Percolation(4);
        int row, col;

        row = 4;
        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        row = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);

        row = 2;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        row = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(1, 1) " + TEST_PASSED);
        else
            StdOut.println("open(1, 1) " + TEST_FAILED);
    }

    private static void test4() {
        StdOut.println("TEST 4: percolation verticale haut vers bas non linéaire");
        Percolation perc = new Percolation(4);
        int row, col;

        row = 1;
        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(1, 1) " + TEST_PASSED);
        else
            StdOut.println("open(1, 1) " + TEST_FAILED);

        row = 2;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        row = 4;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        row = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);
    }

    private static void test5() {
        StdOut.println("TEST 5: percolation verticale bas vers haut non linéaire");
        Percolation perc = new Percolation(4);
        int row, col;

        row = 4;
        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        row = 2;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        row = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(1, 1) " + TEST_PASSED);
        else
            StdOut.println("open(1, 1) " + TEST_FAILED);

        row = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);
    }

    private static void test6() {
        StdOut.println("TEST 6: percolation aléatoire no backwash");
        Percolation perc = new Percolation(4);
        int row, col;

        row = 3;
        col = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(3, 3) " + TEST_PASSED);
        else
            StdOut.println("open(3,3) " + TEST_FAILED);

        row = 2;
        col = 4;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(2, 4) " + TEST_PASSED);
        else
            StdOut.println("open(2, 4) " + TEST_FAILED);

        row = 1;
        col = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col))
            StdOut.println("open(1, 3) " + TEST_PASSED);
        else
            StdOut.println("open(1, 3) " + TEST_FAILED);

        row = 4;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(4, 3) " + TEST_PASSED);
        else
            StdOut.println("open(4, 3) " + TEST_FAILED);

        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col))
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        row = 2;
        col = 3;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(2, 3) " + TEST_PASSED);
        else
            StdOut.println("open(2, 3) " + TEST_FAILED);

        row = 3;
        col = 4;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(3, 4) " + TEST_PASSED);
        else
            StdOut.println("open(3, 4) " + TEST_FAILED);

        if (perc.isOpen(4, 1) && !perc.isFull(4, 1) && perc.percolates())
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        col = 1;
        perc.open(row, col);
        if (perc.isOpen(row, col) && !perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);

        col = 2;
        perc.open(row, col);
        if (perc.isOpen(row, col) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(3, 2) " + TEST_PASSED);
        else
            StdOut.println("open(3, 2) " + TEST_FAILED);

        if (perc.isOpen(4, 1) && perc.isFull(row, col) && perc.percolates())
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

    }

    private static void test7() {
        StdOut.println("TEST 7: percolation aléatoire no backwash");
        Percolation perc = new Percolation(4);

        perc.open(4, 1);
        if (perc.isOpen(4, 1) && !perc.isFull(4, 1) && !perc.percolates())
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        perc.open(2, 1);
        if (perc.isOpen(2, 1) && !perc.isFull(2, 1) && !perc.percolates())
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        perc.open(3, 1);
        if (perc.isOpen(3, 1) && !perc.isFull(3, 1) && !perc.percolates())
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);

        perc.open(1, 1);
        if (perc.isOpen(1, 1) && perc.isFull(1, 1) && perc.percolates())
            StdOut.println("open(1, 1) " + TEST_PASSED);
        else
            StdOut.println("open(1, 1) " + TEST_FAILED);

        if (perc.isOpen(2, 1) && perc.isFull(2, 1) && perc.percolates())
            StdOut.println("open(2, 1) " + TEST_PASSED);
        else
            StdOut.println("open(2, 1) " + TEST_FAILED);

        if (perc.isOpen(3, 1) && perc.isFull(3, 1) && perc.percolates())
            StdOut.println("open(3, 1) " + TEST_PASSED);
        else
            StdOut.println("open(3, 1) " + TEST_FAILED);

        if (perc.isOpen(4, 1) && perc.isFull(4, 1) && perc.percolates())
            StdOut.println("open(4, 1) " + TEST_PASSED);
        else
            StdOut.println("open(4, 1) " + TEST_FAILED);

        perc.open(4, 4);
        if (perc.isOpen(4, 4) && !perc.isFull(4, 4) && perc.percolates())
            StdOut.println("open(4, 4) " + TEST_PASSED);
        else
            StdOut.println("open(4, 4) " + TEST_FAILED);

        perc.open(4, 2);
        if (perc.isOpen(4, 4) && perc.isFull(3, 1) && perc.percolates())
            StdOut.println("open(4, 2) " + TEST_PASSED);
        else
            StdOut.println("open(4, 2) " + TEST_FAILED);

    }

    public static void main(String[] args) {
        PercolationTests.test1();
        PercolationTests.test2();
        PercolationTests.test3();
        PercolationTests.test4();
        PercolationTests.test5();
        PercolationTests.test6();
        PercolationTests.test7();

    }
}
